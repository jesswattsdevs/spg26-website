<?php
session_start();
?>

<html>
    <head>
        <title> Online-Test Index Page </title>
		<style> .error {color:red;} </style>
		
    </head>
    <body>
	<?php
		include "lib01.php";
		
		if($_SERVER["REQUEST_METHOD"]=="POST"){
			//get user info from the form
			$email=test_input($_POST["email"]);
			$pw=test_input($_POST["pw"]);
			
			include "connection.php";
			//query based on email address
			$sqs="SELECT * FROM users WHERE email='$email'";
			$result=mysqli_query($dbc, $sqs);
			$numrows=mysqli_num_rows($result);
			echo "Number of rows is ".$numrows."<br>";
			if($numrows==1){
				$row=mysqli_fetch_array($result);
				$dbpw=$row["pw"]; //pw is the column name in the database table 'users'
				$dbfirstname=$row["firstname"];
				$dbuser_type=$row["user_type"];
				$_SESSION["id"]=$row["id"]; //$_SESSION["id"] is available throughout the application
				$_SESSION["firstname"] = $dbfirstname;
				$verified=password_verify($pw, $dbpw);
				if($verified || $pw==$dbpw){ // be able to handle the legacy users
					if($dbuser_type==0){ //0 indicates admin user
						header("Location:admin_home.php");
					}else{
						echo "Welcome to our website, ".$dbfirstname."!<br>";
						header("Location:user_home.php");
					}
				} else {
					echo "Sorry, Password is NOT correct. Please try again!";
				}
			}else if($numrows==0){
				echo "Sorry, your email is not in the system. Please register!";
			} else {
				echo "Something is wrong. Please try again later.";
			}
			mysqli_close($dbc);
		}
	?>
	<h2> Phase 1 Functions </h2>
	<ol>
		<li> admin login:show admin nav </li>
		<li> admin: display/manage all users </li>
		<li> admin: edit user </li>
		<li> admin: delete user </li>
		<li> User login: show user nav </li>
		<li> Apply session &nbsp; </li>
		<li> Build the quizzes </li>
	</ol>
	
	<h2> Phase 2 Functions </h2>
	<ol>
		<li> Password encryption </li>
		<li> Add pic to user_home (profile picture) </li>
		<li> Upload/update user_resume (pdf file)</li>
		<li> Add user take quiz functions </li>
		<li> Admin: display quiz results and pw</li>
	</ol>
	<p> Submitted by Jessica Watts  </p>
	<hr>
	<h1> Welcome to Jimmy's Free Online Testing Site </h1>
	<p> If you already have an account with us, please login. <p>
	<p> Otherwise, please <a href="registration.php">sign up</a> <p>
	
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
	Email: <input type="text" name="email" maxlength="50"> <br><br>
	Password: <input type="password" name="pw" maxlength="15" id="psw"> <br><br>
	<input type="submit" name="login" value="LOGIN">
	</form>
    
    </body>
</html>