<html> 
<head>
    <title> Admin Edit Users </title>
</head>
<body> 

<?php
include "admin_nav.php";
$id=$_GET["id"]; //id is coming from the url

echo "user id is: ".$id."<br>";

include "connection.php";
$sqs= "SELECT * FROM users WHERE id=$id";
//echo "My sql statement is ".$sqs."<br>";
$result = mysqli_query($dbc, $sqs);
$num= mysqli_num_rows($result);
if($num==1){
    //get the user information
    $row= mysqli_fetch_array($result);
    $dbfirstname=$row["firstname"];
    $dblastname=$row["lastname"];
    $dbemail=$row["email"];
    $dbphone=$row["phone"];
    $dbpw=$row["pw"];
    $dbid=$row["id"];

}else {
    echo "Something is wrong!";
}
?>

<h4> Are you sure you want to update the following user:  </h4>
<form action ="edit.php" method="post">
<input type="hidden" name="id" value="<?php  echo $dbid; ?>" > <br><br> 
First Name: <input type="text" name="firstname" value="<?php echo $dbfirstname; ?>" > <br><br>
Last Name: <input type="text" name="lastname" value="<?php echo $dblastname; ?>" > <br><br>
Email: <input type="text" name="email" value="<?php echo $dbemail; ?>" > <br><br>
Phone: <input type="text" name="phone" value="<?php echo $dbphone; ?>" > <br><br>
Password: <input type="text" name="pw" value="<?php echo $dbpw; ?>" > <br><br>
<input type="submit" name="update" value="CONFIRM UPDATE">
</form>
</body>
</html>