<html>
<head>
    <title> Online Test - Admin User Home </title>
</head>
<body>
    <h2> Welcome to the Admin Portal </h2>
    <p> Admin can delete or edit user information. Admin can also check the evaluation result of each user. </p>
<?php
    include "admin_nav.php";

?>

</body>
</html>