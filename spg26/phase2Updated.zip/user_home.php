<?php
    session_start();
    if(!isset($_SESSION["id"])) {
        header("Location: index.php");
        exit();
    }
    $id = $_SESSION["id"];
    $firstname = $_SESSION["firstname"];
?>

<!DOCTYPE html>
<html>
<head>
    <title> Online Test - User Home </title>
</head>
<body>
    <h2> Hello, <?php echo $firstname; ?>. Welcome to the Free Online Testing Site! </h2>
    <p>Feel free to evaluate your Web Development Skills using our tests. </p>

    <?php
        include "user_nav.php";
        include "lib01.php";
        include "connection.php";

        // Upload
        if(isset($_POST["submit"])){
            $tagName = "myimage"; // <input name="myimage">
            $fileAllowed = "png:jpg:jpeg:gif";
            $sizeAllowed = 9000000; 
            $overwriteAllowed = 1;
            
            $file = uploadFile($tagName, $fileAllowed, $sizeAllowed, $overwriteAllowed);
            
            if($file != false){
                // Update database: column 'pic'
                $sqs = "UPDATE users SET pic='$file' WHERE id=$id";
                mysqli_query($dbc, $sqs);
                echo "<p style='color:green;'>Upload Successful!</p>";
            } else {
                echo "<p style='color:red;'>Upload Failed. Check if the 'uploaded' folder exists.</p>";
            }
        }

        // 2.Display the Picture
        $sqs = "SELECT pic FROM users WHERE id=$id";
        $qresult = mysqli_query($dbc, $sqs);
        $row = mysqli_fetch_array($qresult);
        
        if(!empty($row['pic'])){
            echo "<br><img src='".$row['pic']."' width='200' alt='Profile Picture'><br>";
        } else {
            echo "<p>No profile picture found.</p>";
        }
    ?>

    <form action="user_home.php" method="post" enctype="multipart/form-data">
        Upload/Update your profile picture: 
        <input type="file" name="myimage"> <br><br>
        <input type="submit" name="submit" value="UPLOAD">
    </form>

</body>
</html>