<?php
$hostname = "localhost";
$username = "root";              
$password = "";                  
$dbname = "spg26";

$dbc=mysqli_connect($hostname,$username,$password,$dbname) OR die("Cannot connect to database!");
echo "Connected to the database ".$dbname." successfully! <br>";
?>