<?php
session_start(); 

$id = isset($_SESSION["id"]) ? $_SESSION["id"] : "Not Logged In";

// Dev check: Display the current User ID
echo "ID of this user is " . htmlspecialchars($id) . "<br>";
?>

<html>
<head>
    <title> HTML/CSS Evaluation </title>
</head>
<body>

<?php
include "user_nav.php";

// Initialize variables 
$Q1Mesg = $Q2Mesg = ""; 
$Q1 = $Q2 = "";
$flag = 0; 
$quizScore = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    
    // Q1
    if (empty($_POST["Q1"])) {
        $Q1Mesg = "Please answer this question.";
        $flag = 1;
    } else {
        $Q1 = $_POST["Q1"]; 
        if ($Q1 == "B") { 
            $Q1Mesg = "Good job!";
            $quizScore++;
        } else {
            $Q1Mesg = "Sorry, not correct.";
        }
    }

    // Q2
    if (empty($_POST["Q2"])) {
        $Q2Mesg = "Please answer this question.";
        $flag = 1;
    } else {
        $Q2 = $_POST["Q2"]; 
        if ($Q2 == "A") { 
            $Q2Mesg = "Good job!";
            $quizScore++;
        } else {
            $Q2Mesg = "Sorry, not correct.";
        }
    }

    
    if ($flag == 0 && $id !== "Not Logged In") {
        $quizResult = ($quizScore / 2) * 100;
        
        include "connection.php";
        echo "Connected to the database successfully!<br>";
        
        $sqs = "UPDATE users SET `htmlcss` = $quizResult WHERE id = " . intval($id);
        $returnValue = mysqli_query($dbc, $sqs);
        
        if ($returnValue) {
            echo "<p style='color:green;'>Thank you for completing the HTML/CSS assessment. Your Score: $quizResult%</p>";
        } else {
            echo "<p class='error'>We had trouble saving your result: " . mysqli_error($dbc) . "</p>";
        }
        mysqli_close($dbc);
    }
}
?>

<h1> HTML/CSS Evaluation Questions </h1>
<p> This page will help you evaluate your web structure and styling skills. </p>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    
    <p>1. Which HTML tag is used to define a hyperlink? <span class="error">* <?php echo $Q1Mesg; ?> </span><br>
    <input type="radio" name="Q1" value="A" <?php if($Q1=="A") echo "checked"; ?>> &lt;link&gt;
    <input type="radio" name="Q1" value="B" <?php if($Q1=="B") echo "checked"; ?>> &lt;a&gt;
    <input type="radio" name="Q1" value="C" <?php if($Q1=="C") echo "checked"; ?>> &lt;href&gt;
    </p>

    <p>2. Which CSS property changes background color? <span class="error">* <?php echo $Q2Mesg; ?> </span><br>
    <input type="radio" name="Q2" value="A" <?php if($Q2=="A") echo "checked"; ?>> background-color
    <input type="radio" name="Q2" value="B" <?php if($Q2=="B") echo "checked"; ?>> color
    <input type="radio" name="Q2" value="C" <?php if($Q2=="C") echo "checked"; ?>> bgcolor
    </p>

    <input type="submit" value="Submit">
</form>

</body>
</html>