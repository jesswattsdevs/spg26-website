<?php
session_start();
$id=$_SESSION["id"];
$firstname=$_SESSION["firstname"];

?>

<html> 
<head>
    <title> Online Test- Result </title>

</head>
<body> 

<?php
include "user_nav.php";
?>
<h2>Hi <?php echo $firstname; ?>, Heres your evulation result. </h2>

<?php
include "connection.php";

$sqs="SELECT * FROM users WHERE id='$id'";
        $result=mysqli_query($dbc, $sqs);
        $numrows=mysqli_num_rows($result);
        //echo" Num of rows is".$numrows;
        if($numrows==1){
            $row=mysqli_fetch_array($result);
            $dbphp=$row["php"];
            echo "The php evaultion result is: ".$dbphp.".<br>";
        }
        else {
            echo " Sorry, were having trouble with your evalution result. ";
        }

?>

</body>
</html>
