<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include "connection.php";

    $id = $_POST["id"];
    $email = $_POST["email"];
    
    $sqs = "DELETE FROM users WHERE id=$id";
    mysqli_query($dbc, $sqs);
    
    echo "This user with email " . $email . " has been deleted!";
    echo "<br> Please <a href='admin_manage.php'>click here </a> to go back"; 
}
?>