<?php
session_start();
include "lib01.php";

$firstname = $lastname = $password1 = $password2 = "";
$phone = "111-222-1234";
$email = $gender = $level = "";
$firstnameErr=$lastnameErr=$passwordErr=$emailErr=$genderErr=$phoneErr=$levelErr="";
$flag = 0; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Get information from the form
    $firstname=test_input($_POST["firstname"]);
    $lastname=test_input($_POST["lastname"]);
    $phone=test_input($_POST["phone"]);
    $password1=test_input($_POST["password1"]);
    $password2=test_input($_POST["password2"]);
    $email=test_input($_POST["email"]);
    $gender=$_POST["gender"];
    $level=$_POST["level"];

    // Validation Logic
    if (empty($firstname)) { $firstnameErr = "First name is required!"; $flag = 1; }
    if (empty($lastname)) { $lastnameErr = "Last name is required!"; $flag = 1; }
    if (empty($email)) { $emailErr = "Email is required!"; $flag = 1; }
    if (empty($password1) || $password1 != $password2) { $passwordErr = "Passwords must match!"; $flag = 1; }
    if (empty($gender)) { $genderErr = "Gender is required."; $flag = 1; }
    if ($level == "" || $level == "---") { $levelErr = "IT credits required!"; $flag = 1; }

    if ($flag == 0) {
        include "connection.php";
        // Checking existing email/phone
        $sqs = "SELECT * FROM users WHERE email='$email' OR phone='$phone'";
        $qresult = mysqli_query($dbc, $sqs);
        
        if (mysqli_num_rows($qresult) > 0) {
            $dbError = "Email or Phone Number already exists!";
        } else {
            // Hash password for Phase 2 security
            $hashed_pw = password_hash($password1, PASSWORD_DEFAULT);
            
            // 2. UPDATED INSERT STATEMENT match your database structure exactly
            // Sets default 0 for scores and empty string for pic
            $sql = "INSERT INTO users (firstname, lastname, phone, email, gender, level, pw, user_type, php, sql, htmlcss, pic) 
                    VALUES ('$firstname', '$lastname', '$phone', '$email', '$gender', '$level', '$hashed_pw', 1, 0, 0, 0, '')";
            
            if (mysqli_query($dbc, $sql)) {
                mysqli_close($dbc);
                header("Location: registrationsuccess.php");
                exit();
            } else {
                $dbError = "Database Error: " . mysqli_error($dbc);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Registration </title>
    <style> .error{color:#FF0000;}  </style>
<body>
    <h2> Registration Form </h2>

    <?php if(isset($dbError)) echo "<p class='error'>$dbError</p>"; ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        First Name: <input type="text" name="firstname" value="<?php echo $firstname; ?>"> 
        <span class="error"> * <?php echo $fnameErr; ?> </span><br><br>
        
        Last Name: <input type="text" name="lastname" value="<?php echo $lastname; ?>"> 
        <span class="error"> * <?php echo $lnameErr; ?> </span><br><br>
        
        Phone Number: <input type="text" name="phone" value="<?php echo $phone; ?>"> 
        <span class="error"> * <?php echo $phoneErr; ?> </span><br><br>
        
        Email: <input type="text" name="email" value="<?php echo $email; ?>"> 
        <span class="error"> * <?php echo $emailErr; ?> </span><br><br>
        
        Password: <input type="password" name="password1" maxlength="15"> 
        <span class="error"> * <?php echo $passwordErr; ?> </span><br><br>
        
        Confirm Password: <input type="password" name="password2" maxlength="15"><br><br>
        
        Gender: <span class="error"> * <?php echo $genderErr; ?> </span><br>
        <input type="radio" name="gender" value="Female" <?php if($gender=="Female") echo "checked";?>> Female
        <input type="radio" name="gender" value="Male" <?php if($gender=="Male") echo "checked";?>> Male
        <input type="radio" name="gender" value="Other" <?php if($gender=="Other") echo "checked";?>> Prefer not to say<br><br>
        
        IT Credits Earned: <span class="error"> * <?php echo $levelErr; ?> </span><br>
        <select name="level">
            <option> --- </option>
            <option value="freshman" <?php if($level=="freshman") echo "selected";?>>Less than 30 hours</option>
            <option value="sophomore" <?php if($level=="sophomore") echo "selected";?>>30 - 60 hours</option>
            <option value="junior" <?php if($level=="junior") echo "selected";?>>60 - 90 hours</option>
            <option value="senior" <?php if($level=="senior") echo "selected";?>>More than 90 hours</option>
        </select>
        <br><br>
        
        <input type="submit" value="Register">
    </form>
</body>
</html>