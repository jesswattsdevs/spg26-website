<html> 
<head>
    <title> Online Test- Admin Manage Users </title>
</head>

<body>
<h2>Hello, Welcome to Admin-Manage Users Page! </h2>

<?php
include "admin_nav.php";
include "connection.php";

    $sqs= "SELECT * FROM users ORDER BY firstname ASC";
    $result= mysqli_query($dbc, $sqs);

    //create a table to show query result
    echo "<table border='1' width='80%'>";
    echo "<tr>
    <td> Edit </td>
    <td> Delete </td>
    <td> ID </td>
    <td> First Name </td>
    <td> Last Name </td>
    <td> Phone </td>
    <td> Email </td>
    <td> Level </td>
    <td> PW </td>
    ";
    echo "<tr>";
    while($row=mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td> <a href='admin_edit.php? id=".$row['id']." '> edit </a></td>";
        echo "<td> <a href='admin_delete.php? id=".$row['id']." '> delete </a></td>";
        echo "<td> ".$row['id']." </td>";
        echo "<td> ".$row['firstname']." </td>";
        echo "<td> ".$row['lastname']." </td>";
        echo "<td> ".$row['phone']." </td>";
        echo "<td> ".$row['email']." </td>";
        echo "<td> ".$row['pw']." </td>";
        echo"</tr>";
    }
    echo "<table>";

?>

</body>
</html>