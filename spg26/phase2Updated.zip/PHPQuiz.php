<?php
// Start session to fix "Undefined array key" error
session_start(); 
$id = isset($_SESSION["id"]) ? $_SESSION["id"] : "Not Logged In";

// Dev check from professor's code
echo "ID of this user is " . $id . "<br>";
?>

<html>
<head>
    <title> PHP Evaluation </title>
    <style> .error {color:#FF0000;} </style>
</head>
<body>

<?php
include "user_nav.php";

// Initialize variables to clear "Undefined variable" errors
$Q1Mesg = $Q2Mesg = ""; 
$Q1 = $Q2 = "";
$flag = 0; 
$quizScore = 0;

// Correct superglobal usage: $_SERVER
if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    
    // --- Question 1 Logic ---
    if (empty($_POST["Q1"])) {
        $Q1Mesg = "Please answer this question.";
        $flag = 1;
    } else {
        // IMPORTANT: Assign the posted value to $Q1 FIRST
        $Q1 = $_POST["Q1"]; 
        if ($Q1 == "B") { // Correct answer for 45+25 is 70
            $Q1Mesg = "Good job!";
            $quizScore++;
        } else {
            $Q1Mesg = "Sorry, not correct.";
        }
    }

    // --- Question 2 Logic ---
    if (empty($_POST["Q2"])) {
        $Q2Mesg = "Please answer this question.";
        $flag = 1;
    } else {
        // IMPORTANT: Assign the posted value to $Q2 FIRST
        $Q2 = $_POST["Q2"]; 
        if ($Q2 == "A") { // Correct answer for 40+20 is 60
            $Q2Mesg = "Good job!";
            $quizScore++;
        } else {
            $Q2Mesg = "Sorry, not correct.";
        }
    }

    // Database Update Logic
    if ($flag == 0) {
        $quizResult = ($quizScore / 10) * 100;
        
        include "connection.php";
        $sqs = "UPDATE users SET php=$quizResult WHERE id=$id";
        $returnValue = mysqli_query($dbc, $sqs);
        
        if ($returnValue) {
            echo "Thank you for completing the php assessment.";
        } else {
            echo "We have trouble saving your result. Something is wrong...";
        }
        mysqli_close($dbc);
    }
}
?>

<h1> PHP Evaluation Questions </h1>
<p> This page will help you evaluate your PHP skills. </p>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    
    <p>1. What is the result of 45+25? <span class="error">* <?php echo $Q1Mesg; ?> </span><br>
    <input type="radio" name="Q1" value="A" <?php if($Q1=="A") echo "checked"; ?>> 60
    <input type="radio" name="Q1" value="B" <?php if($Q1=="B") echo "checked"; ?>> 70
    <input type="radio" name="Q1" value="C" <?php if($Q1=="C") echo "checked"; ?>> 80
    <input type="radio" name="Q1" value="D" <?php if($Q1=="D") echo "checked"; ?>> None of those
    </p>

    <p>2. What is the result of 40+20? <span class="error">* <?php echo $Q2Mesg; ?> </span><br>
    <input type="radio" name="Q2" value="A" <?php if($Q2=="A") echo "checked"; ?>> 60
    <input type="radio" name="Q2" value="B" <?php if($Q2=="B") echo "checked"; ?>> 70
    <input type="radio" name="Q2" value="C" <?php if($Q2=="C") echo "checked"; ?>> 80
    <input type="radio" name="Q2" value="D" <?php if($Q2=="D") echo "checked"; ?>> None of those
    </p>

    <input type="submit" value="Submit">
</form>

</body>
</html>