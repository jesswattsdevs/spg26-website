<html>
<head>
    <title> Online Test - Admin Nav Page </title>
</head>
<body>
    <h3 align="center">
        <a href="admin_home.php"> Home </a>
        |
        <a href="admin_manage.php"> Admin Manage Users </a>
        |
        <a href="logout.php"> Logout </a>
    </h3>
</body>
</html>