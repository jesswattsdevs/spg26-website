<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
	

	//update based on id or email
	$id=$_POST["id"];
	include "connection.php";
	$firstname=mysqli_real_escape_string($dbc, trim($_POST["firstname"]));
	$lastname=mysqli_real_escape_string($dbc, trim($_POST["lastname"]));
	$email=mysqli_real_escape_string($dbc, trim($_POST["email"]));
	$phone=mysqli_real_escape_string($dbc, trim($_POST["phone"]));
	$pw=mysqli_real_escape_string($dbc, trim($_POST["pw"]));

	//update based on user id
	$sqs="UPDATE users SET firstname=$'firstname', lastname='$lastname', email='$email', phone='$phone', pw='$pw' WHERE id='$id'";
	echo "SQL statement is ".$sqs."<br>";
	mysqli_query($dbc, $sqs);
	if(mysqli_affected_rows($dbc)==1){
	echo "You have successfully updated this user with email ".$email."<br>";
	echo "Please <a href='admin_manage.php'>click here to go back.</a>";
	}
	else{
		echo "Something is wrong with the update.";
	}
	mysqli_close($dbc);
}
?>