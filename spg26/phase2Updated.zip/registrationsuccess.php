<html>
<head>
<title> Registration Success Page </title>
</head>
<body>
<h2> Thank you for registering with us!</h2>
<h2> Please <a href= "index.php"> click here </a> to login </h2>
</body>
</html>